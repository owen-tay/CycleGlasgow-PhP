<?php

$url = $_SERVER['REQUEST_URI'];


if(!isset($_SESSION['username'])){

    

}



?>