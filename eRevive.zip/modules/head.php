<title>Form examples</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="./dist/output.css" rel="stylesheet">
<script src="../path/to/flowbite/dist/flowbite.min.js"></script>
