/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*.{js,php}"],
  theme: {
    extend: {},
  },
  plugins: [
    require('flowbite/plugin')
  ],
}
